//
//  ViewController.swift
//  StackViewInNavigationBar
//
//  Created by Nitin Bhatia on 14/03/22.
//

import UIKit


class ViewController: UIViewController,UIScrollViewDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        scrollView.delegate = self
        setupNavBar()
    }
    
    
    
    
    let fbLogoImageView = UIImageView(image: UIImage(named: "fb_logo"), contentMode: .scaleAspectFit)
     lazy var searchButton = UIButton(image: UIImage(named: "search")!, tintColor: .black)
     
     lazy var messageButton = UIButton(image: UIImage(named: "messenger")!, tintColor: .black)
    
    fileprivate func setupNavBar() {
        let coverWhiteView = UIView(backgroundColor: .white)
        view.addSubview(coverWhiteView)
        coverWhiteView.anchor(top: view.topAnchor, leading: view.leadingAnchor, bottom: nil, trailing: view.trailingAnchor)
        let safeAreaTop = UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.safeAreaInsets.top ?? 0
        coverWhiteView.constrainHeight(safeAreaTop)
        
        [searchButton, messageButton].forEach { (button) in
            button.layer.cornerRadius = 17
            button.clipsToBounds = true
            button.backgroundColor = .init(white: 0.9, alpha: 1)
            button.withSize(.init(width: 34, height: 34))
        }
        
        navigationController?.navigationBar.barTintColor = .white
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.tintColor = .white
        
        let titleView = UIView(backgroundColor: .clear)
       
        let lessWidth: CGFloat = 34 + 34 + 120 + 24 + 16
        let width = (view.frame.width - lessWidth)
        titleView.hstack(fbLogoImageView.withWidth(120), UIView().withWidth(width), searchButton, messageButton, spacing: 8).padBottom(8)
        navigationItem.titleView = titleView
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if (scrollView.contentOffset.y >= (scrollView.contentSize.height - scrollView.frame.size.height)) {
                // Bottom
                
            }

            if (scrollView.contentOffset.y < 0){
                // Top
                
                [searchButton, messageButton, fbLogoImageView].forEach{$0.alpha = 1}

                
            }

            if (scrollView.contentOffset.y >= 0 && scrollView.contentOffset.y < (scrollView.contentSize.height - scrollView.frame.size.height)){
                // Middle
                
                let totalScroll = scrollView.contentSize.height - scrollView.bounds.size.height;

                
                let percentage: CGFloat = (scrollView.contentOffset.y) / totalScroll
                
                navigationController?.navigationBar.transform = .init(translationX: 0, y: -(percentage))
                
                // This label loses alpha when you scroll down (or slide up)
                //lblTitleHeader.alpha = (percentage)
                

                // This label gets more alpha when you scroll up (or slide down)
                //lblTitleBody.alpha = (1 - percentage)
                
                UIView.animate(withDuration: 2.0, delay: 0, options: .curveEaseIn, animations: {
                    [self.searchButton, self.messageButton, self.fbLogoImageView].forEach{$0.alpha = (1 - percentage)}
                }, completion: nil)
               

                
            }
        
    }
}

