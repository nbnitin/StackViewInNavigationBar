//
//  UITextField+Tools.swift
//  TTT
//
//  Created by Nitin Bhatia on 11/03/22.
//

import Foundation
import UIKit

extension UITextField {

    public convenience init(placeholder: String) {
        self.init()
        self.placeholder = placeholder
    }

}
